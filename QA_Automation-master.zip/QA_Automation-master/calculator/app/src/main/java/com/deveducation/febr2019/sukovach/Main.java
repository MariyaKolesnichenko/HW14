package com.deveducation.febr2019.sukovach;

public class Main {
    public static void main(String[] args) {

        Core core = new Core();
        core.calculate();

    }
}
