package com.deveducation.febr2019.sukovach;
import org.junit.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CalcTest {

    private Core core;


    @Test
    public void testFlue_1()
    {
        double a = 4;
        double b = 1.2;
        double result = 5.2;
        double factResult = new Core().addition(a, b); // 5.2
        Assert.assertEquals(result, factResult, 0);
    }
    @Test
    public void testFlue_2()
    {
        double a = 6 ;
        double b = 8;
        double result = 14;
        double factResult = new Core().addition(a, b); // 14.0
        Assert.assertEquals(result, factResult, 0);
    }
    @Test
    public void testFlue_3()
    {
        double a = -7;
        double b = 9;
        double result = 2;
        double factResult = new Core().addition(a, b); // 2.0
        Assert.assertEquals(result, factResult, 0);
    }
    @Test
    public void testFlue_4()
    {
        double a = -2;
        double b = -3;
        double result = -5 ;
        double factResult = new Core().addition(a, b); // -5.0
        Assert.assertEquals(result, factResult, 0);
    }
    @Test
    public void testFlue_5()
    {
        double a = 6.4;
        double b = 2.9;
        double result = 9.3;
        double factResult = new Core().addition(a, b); // 9.3
        Assert.assertEquals(result, factResult, 0);
    }
    @Test
    public void testFlue_6()
    {
        double a = -0.9;
        double b = 1.9;
        double result = 1;
        double factResult = new Core().addition(a, b); // 1
        Assert.assertEquals(result, factResult, 0);
    }
    @Test
    public void testDivision_1()
    {
        double a = 6.6;
        double b = 0;
        Object result = new ArithmeticException();
        Object fact = new Core().division (a, b);
        Assert.assertEquals(result, fact);
    }
    @Test
    public void testDivision_2()
    {
        double a = -6;
        double b = 3;
        double result = -2;
        double factResult = new Core().division(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testDivision_3()
    {
        double a = -4;
        double b = -2;
        double result = 2;
        double factResult = new Core().division(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testDivision_4()
    {
        double a = 108;
        double b = 54;
        double result = 2;
        double factResult = new Core().division(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testDivision_5()
    {
        double a = -1;
        double b = 0;
        Object result = new ArithmeticException();
        Object fact = new Core().division (a, b);
        Assert.assertEquals(result, fact);
    }
    @Test
    public void testDivision_6()
    {
        double a = 69.9;
        double b = 3;
        double result = 23.3;
        double factResult = new Core().division(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testSubtraction_1()
    {
        double a = 99;
        double b = 84.5;
        double result = 14.5;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testSubtraction_2()
    {
        double a = 10.6;
        double b = 5.4;
        double result = 5.2;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testSubtraction_3()
    {
        double a = -7;
        double b = -3;
        double result = -4;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testSubtraction_4()
    {
        double a = 0.45;
        double b = 0;
        double result = 0.45;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testSubtraction_5()
    {
        double a = 19;
        double b = -4;
        double result = 23;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testSubtraction_6()
    {
        double a = 1;
        double b = -0.5;
        double result = 1.5;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testMultiplication_1()
    {
        double a = 4;
        double b = 8;
        double result = 32;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testMultiplication_2()
    {
        double a = 0.2;
        double b = 0.4;
        double result = 0.08;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testMultiplication_3()
    {
        double a = -5;
        double b = -8;
        double result = 40;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testMultiplication_4()
    {
        double a = -0.7;
        double b = 2;
        double result = 1.4;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testMultiplication_5()
    {
        double a = 29;
        double b = 0;
        double result = 0;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void testMultiplication_6()
    {
        double a = 0.66;
        double b = 0;
        double result = 0;
        double factResult = new Core().subtraction(a, b);
        Assert.assertEquals(result, factResult,0);
    }
    @Test
    public void square_1()
    {
        double a = 16;
        double fact = new Core ().squareRoot(a);

        Assert.assertEquals (4, fact, 0);
    }

    @Test
    public void square_2()
    {
        double a = 8;
        double fact = new Core ().squareRoot(a);

        Assert.assertEquals (2.82842712474619, fact, 0);
    }

    @Test
    public void square_3()
    {
        double a = 9.4;
        double fact = new Core ().squareRoot(a);

        Assert.assertEquals (3.065941943351178, fact, 0);
    }


}